# CastagnaIT Repository for Kodi 18.x (LEIA) add-ons

[Repository installation file [repository.castagnait-1.0.1.zip]](https://github.com/castagnait/repository.castagnait/raw/master/repository.castagnait-1.0.1.zip)

Installation instructions are in the Wiki contained in the add-on repository.

---

## Content of the repository

- plugin.video.netflix

Updates published through this channel are only release versions, not daily builds.

For any other download links refer to the Readme in the add-on repository
